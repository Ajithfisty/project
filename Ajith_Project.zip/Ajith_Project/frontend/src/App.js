import React from 'react';
import './App.css';
import ListEmployeeComponent from './ListEmployeeComponent';

function App() {
  return (
    <ListEmployeeComponent />
  );
}

export default App;
