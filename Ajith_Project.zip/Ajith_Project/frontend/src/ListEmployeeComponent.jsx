import React, { Component } from 'react';
import EmployeeServices from './EmployeeServices';

class ListEmployeeComponent extends Component {
    constructor() {
        super();
        this.state = {
        Employees: []
        }
    }

    componentDidMount() {
        EmployeeServices.getEmployees().then((res) => {
            this.setState({ Employees: res.data });
        }
        );
    }

    render() {
        return (
            <div>
                <h2 className="text-center"> Employee List</h2>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <tbody>
                            <tr>
                                <th>Employee First Name</th>
                                <th>Employee Last Name</th>
                                <th>Employee Email Id</th>
                            </tr>
                        </tbody>
                        
                        <tbody>
                            {
                                this.state.employees.map (
                                    employees=>
                                        <tr key={employees.id}>
                                            <td> {employees.firstName} </td>
                                            <td> {employees.lastName} </td>
                                            <td> {employees.emailId} </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                    
                </div>
            </div>
        );
    }
}

export default ListEmployeeComponent;
